module com.mycompany.gymsystem1 {
    requires javafx.controls;
    exports com.mycompany.gymsystem1;
}
